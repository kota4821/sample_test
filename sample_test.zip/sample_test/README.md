**Pre-Requirements Necessary to Execute test script**
1. Install NodeJS, NODE Appium(1.22) , JAVA, JDK, ANDROID SDK TOOLS, ANY IDE, testng
2. After the installation depending on the Mac or windows , all the environment / PATH variables need to be updated
3. Clone the project from git repo to ide 
4. Configure IDE specific settings like - JDK etc

**After Cloning the Project**
1. Make sure all the libraries are downloaded as per the POM.xml
2. update the xml file with right settings as per the User's system

**Test Execution**
1. Right-click on the testngAndroidFuelLog.xml and click "Run" or "Debug"
Note - Test execution can be done from Maven or command line (need to be configured as per required)


**Test Results**
1.Test-Output folder is generated for every run which captures - Appium log, execution logger, extent reports
Note - Output can be customized to collect more information depending on requirements

**General Assumptions**
1. Across the Project Test Data is either consumed from XML files or hard coded . This has been done to
- optimize development however in real time test data can be read from config files like json/xml/excel etc or DataProviders 
- can be used.