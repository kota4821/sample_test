package com.test.appium;

import com.test.TestFoundation;
import com.test.utils.GoodSleeper;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebElement;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.AutomationName;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Locale;
import java.util.concurrent.TimeUnit;


/**
 * The means to connect to an Appium environment.
 */
@SuppressWarnings({"EnhancedSwitchMigration", "AssertionCanBeIf"})
public final class AppiumConnector
{

    public static final String APP_PACKAGE_OUS1 = "com.fleetio.go_app";

    public static final String ANDROID_APP_ACTIVITY = "com.fleetio.go_app.features.initial.InitialActivity";

    /** Default Android emulator OS version. */
    public static final String DEFAULT_VERSION_ANDROID_EMULATOR = "9";

    /** Default iOS simulator iOS version. */
    public static final String DEFAULT_VERSION_IOS_SIMULATOR = "14.4";


    /** Timeout for Appium to see an element, in seconds. */
    public static final long TIMEOUT_ELEMENT_ANDROID = 8L;


    /** What Android calls an emulator, as a suffix. */
    static final String ANDROID_EMULATOR_SUFFIX = " Emulator";

    public static final String DEFAULT_APPIUM_SERVER = "http://127.0.0.1:4723/wd/hub";


    /** Error message: Illegal platform. */
    static final String ILLEGAL_PLATFORM = "Illegal platform [%s]";

    static final String DEFAULT_BUNDLE_ID = ""; // TODO add parameter

    static final String DEFAULT_DEVICE_NAME_IOS = "iPhone";
    static final String DEFAULT_DEVICE_NAME_IOS_SIM = "iPhone Simulator";
    static final long DEFAULT_NEW_COMMAND_TIMEOUT = 14400L;
    static final String SIMULATOR_STARTUP_TIMEOUT = "simulatorStartupTimeout";

    static final GoodSleeper sleeper = new GoodSleeper(){};

    /**
     * Set up an Appium driver.
     *
     * @param platform    where the app will run.
     * @param useEmulator {@code true} iff the driver should run on an emulator.
     * @param device      device ID.
     * @param osVer       OS version.
     * @param appLoad     location of an app file to load, or leave empty not to load one.
     * @param automation  Appium automation mode, {@code null} or blank for the default.
     * @param locale      set the i18n locale for the run.
     * @return driver for the test.
     */
    @Nonnull
    public static AndroidDriver<RemoteWebElement> driverSetUp(@Nonnull String appiumServer, String wdaLocalPort, @Nonnull String platform,
                                                             boolean useEmulator, @Nonnull String device,
                                                             @Nonnull String osVer,
                                                             @Nullable String appLoad, @Nullable String automation,
                                                             @Nonnull Locale locale)
    {
        AndroidDriver<RemoteWebElement> driver;
        final long timeout;
        final String version;
        final URL appiumServerURL = getAppiumServerURL(appiumServer);
        switch (platform)
        {
            case MobilePlatform.ANDROID:
                timeout = TIMEOUT_ELEMENT_ANDROID;
                version = osVer.isBlank() ? DEFAULT_VERSION_ANDROID_EMULATOR : osVer;
                try
                {
                    final var capabilities = capabilitiesAndroid(useEmulator, device, version, locale);
                    driver = new AndroidDriver<>(appiumServerURL, capabilitiesAll(capabilities, appLoad));
                }
                catch (WebDriverException wde)
                {
                    final var capabilities = capabilitiesAndroid(useEmulator, device, version, null);
                    driver = new AndroidDriver<>(appiumServerURL, capabilitiesAll(capabilities, appLoad));
                }
                break;

//            case MobilePlatform.IOS:
//                timeout = TIMEOUT_ELEMENT_IOS;
//                version = osVer.isBlank() ? DEFAULT_VERSION_IOS_SIMULATOR : osVer;
//                {
//                    final var capabilities = capabilitiesIos(useEmulator, device, version, automation, locale, wdaLocalPort);
//                    driver = new IOSDriver<>(appiumServerURL, capabilitiesAll(capabilities, resetLevel, appLoad));
//                }
//                break;

            default:
                throw new IllegalStateException(String.format(ILLEGAL_PLATFORM, platform));
        }

        driver.manage().timeouts().implicitlyWait(timeout, TimeUnit.SECONDS);   // element locator wait
        sleeper.sleep(TestFoundation.WAIT_BUFFER * 1000L);
        return driver;
    }

    /**
     * Get the appium URl from url string
     * @param appiumServer url string of the appium server
     @return return the URL of the appium server
     */
    public static URL getAppiumServerURL(String appiumServer)
    {
        URL appiumURL;
        try
        {
            appiumURL = new URL(appiumServer);
        }
        catch (MalformedURLException exc)
        {
            throw new IllegalArgumentException(String.format("Bad URL [%s]: %s", DEFAULT_APPIUM_SERVER, exc.getMessage()), exc);
        }

        return appiumURL;
    }

    /**
     * Get the complete app location from which to load.
     *
     * @param appLoad A name or location for the app file.
     * @return the canonical path to the app file.
     */
    @Nonnull
    public static String getAppPath(@Nonnull String appLoad)
    {
        if (appLoad.isBlank())
        {
            throw new IllegalArgumentException("Argument is blank");
        }

        final File fil = new File(appLoad);
        try
        {
            return fil.getCanonicalPath();
        }
        catch (IOException exc)
        {
            String msg = String.format("App file not found: %s \n%s", fil.getName(), exc);
            throw new IllegalStateException(msg, exc);
        }
    }

    /**
     * Create a {@link DesiredCapabilities} object.
     * Static because it is idempotent.
     *
     * @param capabilities  Platform-dependent capabilitiesAll.
     * @param appLoad       location of an app file to load, or {@code ""} not to load one.
     * @return {@link DesiredCapabilities} suitable for an Appium test.
     */
    @Nonnull
    static DesiredCapabilities capabilitiesAll(@Nonnull DesiredCapabilities capabilities,
                                               @Nullable String appLoad)
    {

        if (appLoad != null && ! appLoad.isBlank())
        {
            capabilities.setCapability(MobileCapabilityType.APP, getAppPath(appLoad));
        }

        capabilities.setCapability(CapabilityType.BROWSER_NAME, (String) null);
        capabilities.setCapability(MobileCapabilityType.ENABLE_PERFORMANCE_LOGGING, false);
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, DEFAULT_NEW_COMMAND_TIMEOUT);
        capabilities.setCapability(CapabilityType.SUPPORTS_NETWORK_CONNECTION, true);
        capabilities.setCapability(CapabilityType.TAKES_SCREENSHOT, true);

        return capabilities;
    }

    /**
     * Create an Android {@link Capabilities} object.
     * Static because it is idempotent.
     *
     * @param useEmulator {@code true} iff should be run on an emulator.
     * @param device      device to test on, blank for the default, or {@code null} for an emulator.
     * @param osVer       OS version.
     * @param locale      set the i18n locale for the run.
     * @return {@link Capabilities} suitable for an Android test.
     */
    @Nonnull
    static DesiredCapabilities capabilitiesAndroid(boolean useEmulator, @Nonnull String device, String osVer,
                                                   @Nullable Locale locale)
    {
        DesiredCapabilities capabilities = DesiredCapabilities.android();
        capabilities.setCapability(CapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
        if (useEmulator)
        {
            capabilities.setCapability(AndroidMobileCapabilityType.AVD, device);
            capabilities.setCapability(MobileCapabilityType.DEVICE_NAME,
                    MobilePlatform.ANDROID + ANDROID_EMULATOR_SUFFIX);
        }
        else
        {
            capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, device);
        }

        capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, osVer);
        capabilities.setCapability(AndroidMobileCapabilityType.ALLOW_TEST_PACKAGES, true);
        capabilities.setCapability(AndroidMobileCapabilityType.ANDROID_DEVICE_READY_TIMEOUT, 600);  // seconds
        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, APP_PACKAGE_OUS1);
        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, ANDROID_APP_ACTIVITY);
        capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.ANDROID_UIAUTOMATOR2);
        capabilities.setCapability(AndroidMobileCapabilityType.AUTO_GRANT_PERMISSIONS, true);

        if (locale != null) // null means do not override device Locale
        {
            final String country = locale.getCountry();
            final String language = locale.getLanguage();
            switch (language)
            {
                case "in":  // Indonesian
                    capabilities.setCapability(MobileCapabilityType.LANGUAGE, "id");
                    break;

                case "iw":  // Hebrew
                    capabilities.setCapability(MobileCapabilityType.LANGUAGE, "he");
                    break;

                default:
                    capabilities.setCapability(MobileCapabilityType.LANGUAGE, language);
                    break;
            }
            capabilities.setCapability(MobileCapabilityType.LOCALE, country);
        }

        capabilities.setCapability(AndroidMobileCapabilityType.SKIP_DEVICE_INITIALIZATION, false);
        return capabilities;
    }

    /**
     * Prevent instantiation.
     */
    private AppiumConnector(){}
}
