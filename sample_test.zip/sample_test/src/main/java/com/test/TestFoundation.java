package com.test;

import com.test.appium.AppiumConnector;
import com.test.utils.GoodSleeper;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.service.local.flags.GeneralServerFlag;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.LocaleUtils;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.RemoteWebElement;
import org.testng.annotations.*;
import javax.annotation.Nonnull;
import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;
import java.util.Locale;
import java.util.logging.Logger;

import static com.test.appium.AppiumConnector.DEFAULT_APPIUM_SERVER;
import static org.testng.Reporter.log;

/**
 */
@SuppressWarnings({"UnnecessaryLocalVariable"})
public abstract class TestFoundation implements GoodSleeper {

    protected static AppiumDriver<RemoteWebElement> driver;

    /**
     * Wait buffer, a safe ways away from an event transition.
     */
    public static final long WAIT_BUFFER = 2L;

    /**
     * Default output/reports directory.
     */
    public static final String OUT_DIR = "/test-output";

    protected Locale locale;
    protected static Logger logger;
    protected String platform;
    public AppiumDriverLocalService service;
    public AppiumServiceBuilder builder;
    public static String lang;


    /**
     * isAlive Utility
     *
     * @param appiumIpAddress - Appium IP
     * @param port            - Appium Port
     * @return boolean - true/false
     */
    @Parameters({"appiumIpAddress", "appiumPort"})
    public static boolean isSocketAliveUtility(String appiumIpAddress, int port) {
        boolean isAlive = false;

        // Creates a socket address from a hostname and a port number
        SocketAddress socketAddress = new InetSocketAddress(appiumIpAddress, port);
        Socket socket = new Socket();

        // Timeout required - it's in milliseconds
        int timeout = 2000;

        log("hostName: " + appiumIpAddress + ", port: " + port);
        try {
            socket.connect(socketAddress, timeout);
            socket.close();
            isAlive = true;

        } catch (SocketTimeoutException exception) {
            System.out.println("SocketTimeoutException " + appiumIpAddress + ":" + port + ". " + exception.getMessage());
        } catch (IOException exception) {
            System.out.println(
                    "IOException - Unable to connect to " + appiumIpAddress + ":" + port + ". " + exception.getMessage());
        }
        return isAlive;
    }

    /**
     * Start's the Appium Server before starting the Test suite or Test Execution
     */
    @BeforeSuite(alwaysRun = true)
    @Parameters({"device", "autoStartServer", "nodeJsLocation", "nodeAppiumLocation", "appiumIpAddress", "appiumPort"})
    public void startServer(String device, boolean autoStartServer, String nodeJsLocation, String nodeAppiumLocation,
                            String appiumIpAddress, int appiumPort) throws IOException {
        logger = Logger.getLogger(String.format("%s-%s", platform, device));
        logger.info("Starting the appium server");

        // Remove the test-output Directory before New Test Execution
        FileUtils.deleteDirectory(new File(System.getProperty("user.dir") + OUT_DIR + "/reports"));
        //initialize the log4j properties
        PropertyConfigurator.configure(System.getProperty("user.dir") + "/src/main/resources/log4j.properties");

        //Logic to auto start appium server
        if (autoStartServer) {
            //check if socket is alive before starting the Appium server
            if (isSocketAliveUtility(appiumIpAddress, appiumPort)) {
                //to kill the nodes on Mac OS
                logger.info("Appium Server is running on :  " + appiumIpAddress + appiumPort);
                String[] stopCommand = new String[]{"sh", "-c", String.format("lsof -P | grep ':%s' | awk '{print $2}' | xargs kill -9", appiumPort)};
                Runtime.getRuntime().exec(stopCommand);
                //wait after stopping existing instance
                sleep(40000);
                logger.info("Appium Server is ready to start, after stopping existing instance");
            } else {
                logger.info("Appium Server is ready to start on :  " + appiumIpAddress + appiumPort);
            }

            try {
                builder = new AppiumServiceBuilder();
                builder.withIPAddress(appiumIpAddress);
                builder.usingPort(appiumPort);
                builder.usingDriverExecutable(new File(nodeJsLocation));
                builder.withAppiumJS(new File(nodeAppiumLocation));
                builder.withArgument(GeneralServerFlag.SESSION_OVERRIDE);
                builder.withArgument(GeneralServerFlag.LOG_LEVEL, "debug");
                builder.withArgument(GeneralServerFlag.LOG_TIMESTAMP);
                builder.withArgument(GeneralServerFlag.LOCAL_TIMEZONE);
                builder.withArgument(GeneralServerFlag.ALLOW_INSECURE, "adb_shell");
                builder.withLogFile(new File(System.getProperty("user.dir") + OUT_DIR + "/reports/appium.log"));

                //Start the server with the builder
                service = AppiumDriverLocalService.buildService(builder);
                service.start();
                logger.info("Server url: " + service.getUrl());


            } catch (Exception e) {
                logger.info("Failed to start appium server");
                e.printStackTrace();
            }

        } else {
            logger.info("User has to manually Start the appium server");
        }

    }

    /**
     * Stops the Appium Server after executing the Test suite or Test Execution
     */
    @AfterSuite(alwaysRun = true)
    @Parameters({"autoStartServer"})
    public void stopServer(boolean autoStartServer) {
        logger.info("Stopping the appium server");
        driver.quit();

        //This works only if user opts for auto start appium server
        if (autoStartServer) {
            service.stop();
        }
    }

    /**
     * Make an output directory for the platform.
     *
     * @param platform the platform (e.g., {@code "Android"}, {@code "iOS"}).
     */
    @BeforeClass(alwaysRun = true)
    @Parameters({"platform"})
    public void setPlatform(@Optional("iOS") @Nonnull String platform) {
        if (platform.isBlank()) {
            throw new IllegalArgumentException(String.format("setPlatform(%s) with empty platform", platform));
        }
        this.platform = platform;
    }

    /**
     * Start the driver.
     *
     * @param device       device on which to run the driver.
     * @param osVer        device OS version.
     * @param appLoad      location of the app file to load.
     * @param emulator     whether to run on an emulator.
     * @param parms        parameters being passed to the current invocation of the current test method.
     */

    @BeforeClass(dependsOnMethods = "setPlatform", alwaysRun = true)
    @Parameters({"appiumServer", "wdaLocalPort", "device", "osVer", "appLoad", "emulator", "locales"})
    public void startDriver(@Optional(DEFAULT_APPIUM_SERVER) @Nonnull String appiumServer,
                            @Optional("") String wdaLocalPort,
                            @Optional("") @Nonnull String device,
                            @Optional("") @Nonnull String osVer,
                            @Optional("") @Nonnull String appLoad,
                            @Optional("") @Nonnull String emulator,
                            @Nonnull Object[] parms,
                            @Optional("") @Nonnull String locales
    ) {
        this.locale = LocaleUtils.toLocale(locales);
        Locale.setDefault(this.locale); // guarantee all in the program space including java itself see this Locale
        lang = locale.getLanguage();

        final var useEmulator = Boolean.parseBoolean(emulator);

        this.driver = AppiumConnector.driverSetUp(
                appiumServer, wdaLocalPort, platform, useEmulator, device, osVer, appLoad, null,
                this.locale);
        logger.info(String.format("%s, %s", this.locale, this.driver.getPlatformName()));

    }

    /**
     * Takes a screenshot when a test case fails {@code Listener class}
     *
     * @param nameOfTestCase name of failed testcase
     */
    public static void getScreenshot(String nameOfTestCase) throws IOException {
        File scrfile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(scrfile, new File(System.getProperty("user.dir") + OUT_DIR + "/reports/failurescreens/" + nameOfTestCase + ".png"));

    }

}