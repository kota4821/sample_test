package com.test.utils;

/** Handle {@link java.lang.Thread#sleep} correctly. */
public interface GoodSleeper
{
    /**
     * Interrupt-handling sleep.
     *
     * @param millis milliseconds to sleep.
     */
    default void sleep(long millis)
    {
        try
        {
            Thread.sleep(millis);
        }
        catch (InterruptedException exc)
        {
            Thread.currentThread().interrupt();
        }
    }
}
