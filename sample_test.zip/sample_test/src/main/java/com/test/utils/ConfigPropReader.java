package com.test.utils;

import java.io.FileInputStream;
import java.util.Properties;

public class ConfigPropReader {

    private FileInputStream ip;

    public Properties initLangProp(String language){
        System.out.println("Lang is ::: " + language);
        Properties prop = new Properties();

        try{
            ip = new FileInputStream("./src/main/resources/lang."+language+".properties");
            prop.load(ip);
        } catch (Exception e){
            System.out.println("Exception is ..." + e);
        }
        return prop;
    }
}
