package com.test.utils;

import com.test.TestFoundation;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.IOException;

/**
 * Testng Listener class to take screenshots when the test case fails
 *
 */
public class Listeners implements ITestListener {

    public void onTestFailure(ITestResult result){
        // screenshot
        String nameOfTestCase = result.getName();
        try {
            TestFoundation.getScreenshot(nameOfTestCase);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }



}
