package com.test.page;

public interface CommonPage {
    boolean isDisplayed();

    void doHome();

    void doBrowser();

    void doVehicles();

    void navigateToFuelEntry();

    void addGallons(String gallons);

    void addOdometer(String odometer);

    void doSave();
}
