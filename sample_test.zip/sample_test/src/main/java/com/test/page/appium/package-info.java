/** Page model - Appium-based. */
package com.test.page.appium;
