package com.test.page;

public interface LogoutPage {
    boolean isDisplayed();

    void doProfilePage();

    void doLogout();
}
