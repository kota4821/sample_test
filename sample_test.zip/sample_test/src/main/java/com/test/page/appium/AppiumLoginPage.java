package com.test.page.appium;

import com.test.page.LoginPage;
import com.test.utils.GoodSleeper;
import org.openqa.selenium.NotFoundException;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.testng.annotations.Parameters;

import static org.testng.AssertJUnit.assertTrue;

/**
 * Appium-based {@link com.test.page.LoginPage}.
 */
@SuppressWarnings("UnnecessaryLocalVariable")
public class AppiumLoginPage<T extends RemoteWebElement> implements LoginPage, GoodSleeper
{

    @AndroidFindBy(id = "activity_login_iv_fleetio_logo")
    @iOSXCUITFindBy(accessibility = "todo")
    private T title;

    @AndroidFindBy(id = "activity_login_tv_email_or_username")
    @iOSXCUITFindBy(accessibility = "todo")
    private T userName;

    @AndroidFindBy(id = "activity_login_tv_password")
    @iOSXCUITFindBy(accessibility = "todo")
    private T password;

    @AndroidFindBy(id = "activity_login_btn_login")
    @iOSXCUITFindBy(accessibility = "todo")
    private T loginBtn;

    @AndroidFindBy(id = "activity_login_btn_forgot_password")
    @iOSXCUITFindBy(accessibility = "todo")
    private T forgotLink;

    @AndroidFindBy(id = "activity_login_btn_log_in_with_google")
    @iOSXCUITFindBy(accessibility = "todo")
    private T googleLogin;

    @AndroidFindBy(id = "login_activity_btn_log_in_with_saml")
    @iOSXCUITFindBy(accessibility = "todo")
    private T samlLogin;

    @AndroidFindBy(id = "menu_home_profile")
    @iOSXCUITFindBy(accessibility = "todo")
    private T homeProfile;


    /**
     * Constructor with a given driver.
     *
     * @param driver shared {@link AppiumDriver}.
     */
    public AppiumLoginPage(AppiumDriver<T> driver)
    {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    @Override
    public boolean isDisplayed()
    {
        try
        {
            final var isDisped = title.isEnabled();
            return isDisped;
        }
        catch (NotFoundException ignore)
        {
            return false;
        }
    }

    @Override
    public void setUserName(CharSequence value){
        userName.clear();
        userName.sendKeys(value);
    }

    @Override
    public void setPassword(CharSequence value){
        password.clear();
        password.sendKeys(value);
    }

    @Override
    public void doLogin(){
        loginBtn.click();
        sleep(2000L);
    }

    @Override
    public boolean isLoggedIn(){
        try
        {
            final var isDisped = homeProfile.isEnabled();
            return isDisped;
        }
        catch (NotFoundException ignore)
        {
            return false;
        }
    }

    /**
     * Helper function to Login
     */
    @Override
    public void login(String email, String auth){
        setUserName(email);
        setPassword(auth);
        doLogin();
    }

}
