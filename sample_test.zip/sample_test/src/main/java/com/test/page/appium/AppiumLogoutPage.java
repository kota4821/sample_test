package com.test.page.appium;

import com.test.helper.ReusableFunctions;
import com.test.page.LogoutPage;
import com.test.utils.GoodSleeper;
import org.openqa.selenium.NotFoundException;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

import static org.testng.Assert.assertTrue;

/**
 * Appium-based {@link com.test.page.LogoutPage}.
 */
@SuppressWarnings("UnnecessaryLocalVariable")
public class AppiumLogoutPage<T extends RemoteWebElement> implements LogoutPage, GoodSleeper
{

    private final AppiumDriver<T> driver;

    @AndroidFindBy(id = "menu_home_profile")
    @iOSXCUITFindBy(accessibility = "todo")
    private T homeProfile;

    @AndroidFindBy(id = "fragment_settings_rv")
    @iOSXCUITFindBy(accessibility = "todo")
    private T scroller;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Log Out']")
    @iOSXCUITFindBy(accessibility = "todo")
    private T logoutBtn;

    @AndroidFindBy(xpath = "//android.widget.Button[@text='LOG OUT']")
    private  T finalLogoutBtn;

    @AndroidFindBy(id = "alertTitle")
    private  T alertTitle;

    /**
     * Constructor with a given driver.
     *
     * @param driver shared {@link AppiumDriver}.
     */
    public AppiumLogoutPage(AppiumDriver<T> driver)
    {
        this.driver = driver;
        PageFactory.initElements(new AppiumFieldDecorator(this.driver), this);
    }

    @Override
    public boolean isDisplayed(){
        try
        {
            final var isDisped = homeProfile.isEnabled();
            return isDisped;
        }
        catch (NotFoundException ignore)
        {
            return false;
        }
    }

    @Override
    public void doProfilePage(){
        homeProfile.click();
    }

    @Override
    public  void doLogout(){
        doProfilePage();
        ReusableFunctions.scroll(driver, scroller, ReusableFunctions.Direction.UP, 0.4);
        logoutBtn.click();
        assertTrue(alertTitle.isDisplayed());
        finalLogoutBtn.click();
    }
}
