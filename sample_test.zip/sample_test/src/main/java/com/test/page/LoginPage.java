package com.test.page;

/** Login  page. */
public interface LoginPage
{
    /**
     * Determine if the page is sufficiently displayed.
     *
     * @return {@code true} if the page is showing.
     */
    boolean isDisplayed();


    void setUserName(CharSequence value);

    void setPassword(CharSequence value);

    /**
     * Do the {@code login} action.
     */
    void doLogin();

    boolean isLoggedIn();

    void login(String value, String value2);
}
