package com.test.page.appium;

import com.test.page.CommonPage;
import com.test.utils.GoodSleeper;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.NotFoundException;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

public class AppiumCommonPage <T extends RemoteWebElement> implements CommonPage, GoodSleeper {
    private final AppiumDriver<T> driver;

    public String gallons;

    @AndroidFindBy(xpath= "//android.widget.FrameLayout[@content-desc=\"Home\"]/android.widget.FrameLayout/android.widget.ImageView")
    @iOSXCUITFindBy(accessibility = "todo")
    private T homeTab;

    @AndroidFindBy(xpath = "//android.widget.FrameLayout[@content-desc=\"Browse\"]/android.view.ViewGroup")
    @iOSXCUITFindBy(accessibility = "todo")
    private T browseTab;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Vehicles']")
    @iOSXCUITFindBy(accessibility = "todo")
    private T vehiclesItem;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='001 FuelEntry - Android']")
    private  T fuelEntryAndroid;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Fuel Log']")
    private  T fuelLog;

    @AndroidFindBy(id = "fab")
    private  T newFuelLogBtn;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='New Fuel Entry']")
    private  T newFuelEntryPage;

    @AndroidFindBy(id = "menu_item_save")
    private  T saveBtn;

    @AndroidFindBy(id = "menu_item_save")
    private  T cancelBtn;

    @AndroidFindBy(id = "item_form_inline_et")
    private List<T> entryList;

    /**
     * Constructor with a given driver.
     *
     * @param driver shared {@link AppiumDriver}.
     */
    public AppiumCommonPage(AppiumDriver<T> driver)
    {
        this.driver = driver;
        PageFactory.initElements(new AppiumFieldDecorator(this.driver), this);
    }

    @Override
    public boolean isDisplayed(){
        try
        {
            final var isDisped = homeTab.isEnabled();
            return isDisped;
        }
        catch (NotFoundException ignore)
        {
            return false;
        }
    }
    @Override
    public void doHome(){
        homeTab.click();
    }

    @Override
    public void doBrowser(){
        browseTab.click();
    }

    @Override
    public void doVehicles(){
        vehiclesItem.click();
    }

    @Override
    public void navigateToFuelEntry(){
        doBrowser();
        doVehicles();
        fuelEntryAndroid.click();
        fuelLog.click();
        newFuelLogBtn.click();
        assertTrue(newFuelEntryPage.isDisplayed());
    }

    @Override
    public void addGallons(String gallons){
        entryList.get(2).sendKeys(gallons);
        entryList.get(2).click();
        entryList.get(1).click();
        driver.navigate().back();
    }

    @Override
    public void addOdometer(String odometer){
        entryList.get(4).sendKeys(odometer);
        entryList.get(4).click();
        entryList.get(1).click();
        driver.navigate().back();
    }

    @Override
    public void doSave(){
        saveBtn.click();
    }



}
