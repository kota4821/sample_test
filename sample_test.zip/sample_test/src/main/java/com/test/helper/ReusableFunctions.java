package com.test.helper;

import com.test.TestFoundation;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;

import javax.annotation.Nonnull;
import java.time.Duration;

public class ReusableFunctions extends TestFoundation {


    public static void hardWait(long millis){
        try
        {
            Thread.sleep(millis);
        }
        catch (InterruptedException exc)
        {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Scroll a screen element in the given direction.
     *
     * @param <T>       Appium element type.
     * @param driver    Driver to issue the command.
     * @param element   Element to scroll.
     * @param direction Direction to scroll.
     * @param offset    Proportion from each end to offset the action.
     */
    public static <T extends RemoteWebElement> void scroll(@Nonnull AppiumDriver<T> driver,
                                                           @Nonnull WebElement element,
                                                           @Nonnull Direction direction,
                                                           double offset)
    {
        final double OFFSETTER = 0.25;
        final Duration SCROLL_DURATION = Duration.ofMillis(750);

        if (offset <= 0.0 || offset >= 1.0 || offset == 0.5)
        {
            offset = OFFSETTER;
        }

        Rectangle elemRect = element.getRect();

        PointOption<?> pressed;
        PointOption<?> released;
        switch (direction)
        {
            case UP -> {
                pressed = PointOption.point(elemRect.getX() + elemRect.getWidth() / 2,
                        elemRect.getY() + (int) (elemRect.getHeight() * (1.0 - offset)));
                released = PointOption.point(elemRect.getX() + elemRect.getWidth() / 2,
                        elemRect.getY() + (int) (elemRect.getHeight() * offset));
            }
            case DOWN -> {
                pressed = PointOption.point(elemRect.getX() + elemRect.getWidth() / 2,
                        elemRect.getY() + (int) (elemRect.getHeight() * offset));
                released = PointOption.point(elemRect.getX() + elemRect.getWidth() / 2,
                        elemRect.getY() + (int) (elemRect.getHeight() * (1.0 - offset)));
            }
            case LEFT -> {
                pressed = PointOption.point(elemRect.getX() + (int) (elemRect.getWidth() * (1.0 - offset)),
                        elemRect.getY() + elemRect.getHeight() / 2);
                released = PointOption.point(elemRect.getX() + (int) (elemRect.getWidth() * offset),
                        elemRect.getY() + elemRect.getHeight() / 2);
            }
            case RIGHT -> {
                pressed = PointOption.point(elemRect.getX() + (int) (elemRect.getWidth() * offset),
                        elemRect.getY() + elemRect.getHeight() / 2);
                released = PointOption.point(elemRect.getX() + (int) (elemRect.getWidth() * (1.0 - offset)),
                        elemRect.getY() + elemRect.getHeight() / 2);
            }
            default -> throw new IllegalStateException(String.format("Impossible Direction [%s]", direction));
        }

        @SuppressWarnings({"unused"})
        TouchAction<?> action = new TouchAction<>(driver)
                .press(pressed)
                .waitAction(WaitOptions.waitOptions(SCROLL_DURATION))
                .moveTo(released)
                .release()
                .perform();
    }

    /** Scroll direction. */
    public enum Direction
    {
        LEFT("left"),
        RIGHT("right"),
        UP("up"),
        DOWN("down");

        private final String representation;

        Direction(@Nonnull String representation)
        {
            this.representation = representation;
        }

        /**
         * Get the {@code String} representation.
         *
         * @return the {@code String} representation.
         */
        @Override
        public String toString()
        {
            return representation;
        }
    }

}
