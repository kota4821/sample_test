package com.test;

import com.test.helper.ReusableFunctions;
import com.test.page.CommonPage;
import com.test.page.LoginPage;
import com.test.page.LogoutPage;
import com.test.page.appium.AppiumCommonPage;
import com.test.page.appium.AppiumLoginPage;
import com.test.page.appium.AppiumLogoutPage;
import org.apache.log4j.Logger;
import org.openqa.selenium.remote.RemoteWebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import java.util.List;

import static org.testng.Assert.*;


public class AddFuelLogTest extends TestFoundation{

    Logger logger = Logger.getLogger("testCasesLogger");

    public String date;
    public String pricePerGallons;
    public String gallons = "4";
    public String total;
    public String odometer = "14000";

    @BeforeMethod
    @Parameters({"email", "auth"})
    public void loginToAccount(String email, String auth){
        logger.info("login to account using username & Password");
        LoginPage loginPage = new AppiumLoginPage<>(driver);
        loginPage.login(email, auth);

    }

    /**
     * Adding a fuel log to existing user
     */
    @Test()
    public void addFuelLog() {
        logger.info("*************Start test::: addFuelLog **********");
        CommonPage commonPage = new AppiumCommonPage<>(driver);

        commonPage.navigateToFuelEntry();
        commonPage.addGallons(gallons);

        // Note - This logic can be moved to common functions
        List<RemoteWebElement> fuelLogDetailsList = driver.findElementsById("item_form_inline_et");
        //Verifies Date field
        assertNotNull(fuelLogDetailsList.get(0).getText());
        date = fuelLogDetailsList.get(0).getText();
        //verifies Price/Gallons
        pricePerGallons = fuelLogDetailsList.get(1).getText();
        List<RemoteWebElement> totalList = driver.findElementsById("item_form_inline_et");
        total = totalList.get(3).getText();

        commonPage.addOdometer(odometer);
        commonPage.doSave();
        ReusableFunctions.hardWait(10000);

        //Step 4 - Actual verifications
        List<RemoteWebElement> fuelLogList = driver.findElementsById("text_view_date");
        fuelLogList.get(0).click();

        List<RemoteWebElement> text = driver.findElementsById("item_txt_description");
        String expectedDate = text.get(0).getText();
        assertNotNull(expectedDate);
        String expectedPricePerGallon = driver.findElementByXPath("//android.widget.TextView[contains(@text, 'PRICE')]/following-sibling::android.widget.TextView").getText();
        assertEquals(expectedPricePerGallon, "$2");
        String expectedOdometer = driver.findElementByXPath("//android.widget.TextView[contains(@text, 'ODOMETER')]/following-sibling::android.widget.TextView").getText();
        assertEquals(expectedOdometer, odometer);
        String expectedGallons = driver.findElementByXPath("//android.widget.TextView[contains(@text, 'GALLONS')]/following-sibling::android.widget.TextView").getText();
        assertEquals(expectedGallons, gallons);
        commonPage.doHome();
    }

    @AfterMethod
    public void logoutOfAccount(){
        logger.info("Logout of Account");
        LogoutPage logoutPage = new AppiumLogoutPage<>(driver);
        logoutPage.doLogout();

    }
}
